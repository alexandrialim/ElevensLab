/**
 * This is a class that tests the Deck class.
 */
public class DeckTester {

	/**
	 * The main method in this class checks the Deck operations for consistency.
	 *	@param args is not used.
	 */
	public static void main(String[] args) {
		String[] ranks = {"Jack", "Queen", "King"};
		String[] suits = {"Black", "Red"};
		int[] pointValue = {11, 12, 13};
		Deck d = new Deck(ranks, suits, pointValue);
		
		System.out.println("Deck size should be 6: " + d.size());
		System.out.println("Deal: " + d.deal());
		System.out.println("IsEmpty: " + d.isEmpty() + "\n");
		
		System.out.println("ToString: \n" + d.toString());
	}
}
